﻿using System;
using System.Collections.Generic;
 
namespace Photobook.Models
{
    public class Person
    {         
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string SN { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string Surname 
        { 
            get => SN; 
            set => SN = value; 
        }

        public string Initials { get; set; }
        public string Title { get; set; }
        public string Company { get; set; }
        public string MemberOf { get; set; }
        public string PrimaryGroupID { get; set; }
        public string GroupCategory { get; set; }
        public string Department { get; set; }
        public string PhysicalDeliveryOfficeName { get; set; }
        
        public string OfficeTelephoneNumber { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string OfficePhone 
        { 
            get => OfficeTelephoneNumber; 
            set => OfficeTelephoneNumber = value; 
        }

        public string TelephoneNumber { get; set; }
        
        public string OtherTelephoneNumber { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string OtherTelephone 
        { 
            get => OtherTelephoneNumber; 
            set => OtherTelephoneNumber = value; 
        }

        public string MobileTelephoneNumber { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string Mobile 
        { 
            get => MobileTelephoneNumber; 
            set => MobileTelephoneNumber = value; 
        }

        public string HomeTelephoneNumber { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string HomePhone 
        { 
            get => HomeTelephoneNumber; 
            set => HomeTelephoneNumber = value; 
        }

        public string UserDeskNumber { get; set; }
        public string SAMAccountName { get; set; }
        public string Description { get; set; }
        
        public string EmailAddress { get; set; }  // Kept for Windows AD compatibility
        
        // Cross-platform alias
        public string Email 
        { 
            get => EmailAddress; 
            set => EmailAddress = value; 
        }

        public int UserAccountControl { get; set; }
        public string Image { get; set; }

        public Person() { } 

        // Windows AD constructor - kept for compatibility
        public Person(System.DirectoryServices.SearchResult result, string[] properties)
        {
            //{ "sAMAccountName", "displayName", "title", "department", "company", "memberOf", "primaryGroupID", "groupCategory", "givenname", "sn", "telephoneNumber", "officePhone", "otherTelephone", "mobile", "homePhone", "physicaldeliveryofficename", "thumbnailPhoto", "description", "emailAddress", "userAccountControl" };
            SAMAccountName = Util.getPropertyValue(result, properties[0]);
            DisplayName = Util.getPropertyValue(result, properties[1]);
            Title = Util.getPropertyValue(result, properties[2]);
            Department = Util.getPropertyValue(result, properties[3]);
            Company = Util.getPropertyValue(result, properties[4]);
            MemberOf = Util.getPropertyValue(result, properties[5]);
            PrimaryGroupID = Util.getPropertyValue(result, properties[6]);
            GroupCategory = Util.getPropertyValue(result, properties[7]);
            GivenName = Util.getPropertyValue(result, properties[8]);
            SN = Util.getPropertyValue(result, properties[9]);
            TelephoneNumber = Util.getPropertyValue(result, properties[10]);
            OfficeTelephoneNumber = Util.getPropertyValue(result, properties[11]);
            OtherTelephoneNumber = Util.getPropertyValue(result, properties[12]);
            MobileTelephoneNumber = Util.getPropertyValue(result, properties[13]);
            HomeTelephoneNumber = Util.getPropertyValue(result, properties[14]);
            PhysicalDeliveryOfficeName = Util.getPropertyValue(result, properties[15]);
            Image = Util.getPropertyImage(result, properties[16]);
            Description = Util.getPropertyValue(result, properties[17]);
            EmailAddress = Util.getPropertyValue(result, properties[18]);
            UserDeskNumber = Util.getPropertyValue(result, properties[19]);
        }
    }
}
