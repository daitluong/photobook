﻿using Photobook.Models;
using System.Diagnostics;
using System.Text;

namespace Photobook.Services
{
    public interface IActiveDirectorySercies
    {
        List<Person> SearchByFullName(string Department, string txtSearch);
    }

    public class ActiveDirectoryServices : IActiveDirectorySercies 
    {
        // Configuration
        private const string Domain = "ldap:://localhost:389";
        private const string LDAP_PATH = "LDAP://cn=admin,DC=photobook,DC=local";
        private const string UserName = "admin";
        private const string Password = "admin123";
        private string userDepartment = "NSC";
        
        // LDAP Configuration for cross-platform support
        private const string LDAP_SERVER = "localhost";
        private const int LDAP_PORT = 389;
        private const string LDAP_BASE_DN = "dc=photobook,dc=local";
        private const string LDAP_ADMIN_DN = "cn=admin,dc=photobook,dc=local";
        private const string LDAP_ADMIN_PASSWORD = "admin123";

        private readonly ILdapProvider _ldapProvider;

        public ActiveDirectoryServices(ILdapProvider ldapProvider = null)
        {
            // Auto-detect platform if provider not provided
            if (ldapProvider != null)
            {
                _ldapProvider = ldapProvider;
            }
            else
            {
                // Default: use System.DirectoryServices on Windows, LDAP command on Linux
                if (OperatingSystem.IsWindows())
                {
                    _ldapProvider = new WindowsDirectoryServicesProvider();
                }
                else
                {
                    _ldapProvider = new CrossPlatformLdapProvider(LDAP_SERVER, LDAP_PORT, LDAP_BASE_DN, LDAP_ADMIN_DN, LDAP_ADMIN_PASSWORD);
                }
            }
        }

        public List<Person> SearchByFullName(string Department, string txtSearch)
        {
            if (!string.IsNullOrWhiteSpace(txtSearch)) 
                txtSearch = txtSearch.Trim().ToLower();
            
            List<Person> people = new List<Person>();

            if (!string.IsNullOrWhiteSpace(Department))
            {
                userDepartment = Department;
            }

            try
            {
                people = _ldapProvider.Search(userDepartment, txtSearch);
                return people;
            }
            catch (Exception exp)
            {
                //System..Diagnostics.Debug.WriteLine($"LDAP Search Error: {exp.Message}");
                throw;
            }
        }
    }

    /// <summary>
    /// Interface for different LDAP provider implementations
    /// </summary>
    public interface ILdapProvider
    {
        List<Person> Search(string department, string searchTerm);
    }

    /// <summary>
    /// Windows-based LDAP provider using System.DirectoryServices
    /// </summary>
    public class WindowsDirectoryServicesProvider : ILdapProvider
    {
        private const string Domain = "ldap:://localhost:389";
        private const string LDAP_PATH = "LDAP://cn=admin,DC=photobook,DC=local";
        private const string UserName = "admin";
        private const string Password = "admin123";
        private const int isActive = 0x40200;
        private string[] propsToLoad = { "sAMAccountName", "displayName", "title", "department", "company", "memberOf", "primaryGroupID", "groupCategory", "givenname", "sn", "telephoneNumber", "officePhone", "otherTelephone", "mobile", "homePhone", "physicaldeliveryofficename", "thumbnailPhoto", "description", "emailAddress", "userAccountControl" };

        public List<Person> Search(string department, string searchTerm)
        {
            List<Person> people = new List<Person>();

            try
            {
                // Use System.DirectoryServices - only works on Windows
                System.DirectoryServices.DirectoryEntry entry = new System.DirectoryServices.DirectoryEntry(LDAP_PATH, UserName, Password);
                string filter = "(&(objectClass=user)(objectCategory=person)(department=" + department + ")(userAccountControl=" + isActive + "))";

                System.DirectoryServices.DirectorySearcher searcher = new System.DirectoryServices.DirectorySearcher(entry, filter, propsToLoad);
                searcher.PropertiesToLoad.AddRange(propsToLoad);

                System.DirectoryServices.SearchResultCollection results = searcher.FindAll();

                foreach (System.DirectoryServices.SearchResult result in results)
                {
                    people.Add(new Person(result, propsToLoad));
                }

                entry.Dispose();
                return people;
            }
            catch (System.PlatformNotSupportedException)
            {
                throw new InvalidOperationException("System.DirectoryServices is not supported on this platform. Use CrossPlatformLdapProvider instead.");
            }
        }
    }

    /// <summary>
    /// Cross-platform LDAP provider using ldapsearch command-line tool
    /// Works on Windows, Linux, and macOS
    /// </summary>
    public class CrossPlatformLdapProvider : ILdapProvider
    {
        private readonly string _ldapServer;
        private readonly int _ldapPort;
        private readonly string _baseDn;
        private readonly string _adminDn;
        private readonly string _adminPassword;

        public CrossPlatformLdapProvider(string ldapServer, int ldapPort, string baseDn, string adminDn, string adminPassword)
        {
            _ldapServer = ldapServer;
            _ldapPort = ldapPort;
            _baseDn = baseDn;
            _adminDn = adminDn;
            _adminPassword = adminPassword;
        }

        public List<Person> Search(string department, string searchTerm)
        {
            List<Person> people = new List<Person>();

            try
            {
                // Build LDAP filter
                string searchBase = $"ou=users,{_baseDn}";
                string filter = BuildLdapFilter(searchTerm);

                // Execute ldapsearch
                string ldapSearchResult = ExecuteLdapSearch(searchBase, filter);

                if (!string.IsNullOrEmpty(ldapSearchResult))
                {
                    people = ParseLdapResults(ldapSearchResult);
                }

                return people;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Cross-platform LDAP search error: {ex.Message}");
                throw;
            }
        }

        private string BuildLdapFilter(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return "(objectClass=inetOrgPerson)";
            }

            return $"(|(displayName=*{EscapeLdapFilter(searchTerm)}*)(mail=*{EscapeLdapFilter(searchTerm)}*)(uid=*{EscapeLdapFilter(searchTerm)}*)(cn=*{EscapeLdapFilter(searchTerm)}*))";
        }

        private string EscapeLdapFilter(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;

            var sb = new StringBuilder();
            foreach (char c in input)
            {
                switch (c)
                {
                    case '*':
                        sb.Append("\\2a");
                        break;
                    case '(':
                        sb.Append("\\28");
                        break;
                    case ')':
                        sb.Append("\\29");
                        break;
                    case '\\':
                        sb.Append("\\5c");
                        break;
                    case '/':
                        sb.Append("\\2f");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }

        private string ExecuteLdapSearch(string searchBase, string filter)
        {
            try
            {
                var processInfo = new ProcessStartInfo
                {
                    FileName = "ldapsearch",
                    Arguments = $"-x -H ldap://{_ldapServer}:{_ldapPort} -D \"{_adminDn}\" -w {_adminPassword} -b \"{searchBase}\" \"{filter}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(processInfo))
                {
                    var output = process.StandardOutput.ReadToEnd();
                    process.WaitForExit();

                    if (process.ExitCode == 0)
                    {
                        return output;
                    }
                    else
                    {
                        var error = process.StandardError.ReadToEnd();
                        System.Diagnostics.Debug.WriteLine($"ldapsearch error: {error}");
                        return string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error executing ldapsearch: {ex.Message}");
                throw;
            }
        }

        private List<Person> ParseLdapResults(string ldapOutput)
        {
            var people = new List<Person>();
            var entries = ldapOutput.Split(new[] { "dn: " }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var entry in entries)
            {
                var lines = entry.Split(new[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                if (lines.Length == 0)
                    continue;

                var personData = new Dictionary<string, string>();

                foreach (var line in lines)
                {
                    if (line.Contains(":"))
                    {
                        var parts = line.Split(new[] { ":" }, 2, StringSplitOptions.None);
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim().ToLower();
                            string value = parts[1].Trim();

                            // Handle base64 encoded values
                            if (value.StartsWith(":"))
                            {
                                value = value.Substring(1).Trim();
                                try
                                {
                                    value = Encoding.UTF8.GetString(Convert.FromBase64String(value));
                                }
                                catch { }
                            }

                            if (!personData.ContainsKey(key))
                                personData[key] = value;
                        }
                    }
                }

                var person = new Person
                {
                    DisplayName = GetValueOrDefault(personData, "displayname", "Update Workday"),
                    Email = GetValueOrDefault(personData, "mail", "Update Workday"),
                    Department = GetValueOrDefault(personData, "department", "Update Workday"),
                    GivenName = GetValueOrDefault(personData, "givenname", "Update Workday"),
                    Surname = GetValueOrDefault(personData, "sn", "Update Workday"),
                    Title = GetValueOrDefault(personData, "title", "Update Workday"),
                    OfficePhone = GetValueOrDefault(personData, "officephone", "Update Workday"),
                    Mobile = GetValueOrDefault(personData, "mobile", "Update Workday"),
                    HomePhone = GetValueOrDefault(personData, "homephone", "Update Workday"),
                    TelephoneNumber = GetValueOrDefault(personData, "telephonenumber", "Update Workday"),
                    Description = GetValueOrDefault(personData, "description", "Update Workday"),
                    Image = handlingThumbnailPhoto(GetValueOrDefault(personData, "thumbnailphoto")),
                    SAMAccountName = GetValueOrDefault(personData, "uid", "Update Workday")
                };

                if (!string.IsNullOrWhiteSpace(person.DisplayName))
                {
                    people.Add(person);
                }
            }

            return people;
        }

        private string handlingThumbnailPhoto(string base64Photo)
        {
            if (string.IsNullOrWhiteSpace(base64Photo))
                return "/images/NSClogo.png";

            return $"data:image/jpeg;base64,{base64Photo}";
        }

        private string GetValueOrDefault(Dictionary<string, string> dict, string key, string defaultValue = "")
        {
            return dict.ContainsKey(key) ? dict[key] : defaultValue;
        }
    }
}
