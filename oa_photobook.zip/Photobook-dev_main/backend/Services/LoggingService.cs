﻿using log4net;

namespace Photobook.Services
{
    public interface ILoggingService
    {
        void LogInfo(string message);
        void LogWaring(string message);
        void LogError(string message, Exception? ex = null);
        void LogDebug(string message);

    }

    public class LoggingService : ILoggingService
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(LoggingService));

        public void LogInfo(string message) => log.Info(message);
        public void LogWaring(string message) => log.Warn(message);
        public void LogError(string message, Exception? ex = null) => log.Error(message, ex);
        public void LogDebug(string message) => log.Debug(message);
    }
}
