
using Photobook.Configurations.AppSetting;
using Photobook.Services; 
using log4net;
using log4net.Config;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);
var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());

XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));  
builder.Services.Configure<ProtectedKeySection>(builder.Configuration.GetSection(ProtectedKeySection.SectionName)); 

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register LDAP provider based on platform
if (OperatingSystem.IsWindows())
{
    // Windows: use System.DirectoryServices
    builder.Services.AddSingleton<IActiveDirectorySercies, ActiveDirectoryServices>();
}
else
{
    // Linux/macOS: use cross-platform LDAP provider
    builder.Services.AddSingleton<ILdapProvider>(sp => 
        new CrossPlatformLdapProvider("localhost", 389, "dc=photobook,dc=local", "cn=admin,dc=photobook,dc=local", "admin123"));
    builder.Services.AddSingleton<IActiveDirectorySercies, ActiveDirectoryServices>();
}

builder.Services.AddSingleton<ILoggingService, LoggingService>(); 

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseCors("AllowAll"); 
app.UseAuthorization();  
app.MapControllers();

app.Run();
