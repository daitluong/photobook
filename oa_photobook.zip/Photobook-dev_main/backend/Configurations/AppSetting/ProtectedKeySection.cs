﻿namespace Photobook.Configurations.AppSetting
{
    public class ProtectedKeySection
    {
        public const string SectionName = "ProtectedKeySection";
        public string ac { get; set; }
        public string pc { get; set; }
        public string ADAccount { get; set; }
        public string ADAccountPwd { get; set; }
        public string root { get; set; }
        public string rootOVP { get; set; }
        public string generalFilter { get; set; }
        public string ldapPath { get; set; }
    }
}
