﻿using System.DirectoryServices;

namespace Photobook
{
    public static class Util
    {
        public static string? getPropertyValue(SearchResult result, string propertyKey)
        {   try
            {
                if (result.Properties.Contains(propertyKey)) 
                    return result.Properties[propertyKey][0].ToString();

                return "Update Workday"; 
            }
            catch (Exception exp)
            {
                return "Update Workday"; 
            }
        }

        public static string? getPropertyImage(SearchResult result, string propertyKey)
        {
            try
            {
                if (result.Properties.Contains(propertyKey))
                    return String.Format("data:image/jpeg;base64,{0}", Convert.ToBase64String((byte[])result.Properties["thumbnailPhoto"][0]));

                return "/images/NSCLogo.png";
            }
            catch (Exception exp)
            {
                return "/images/NSCLogo.png";
            }
        } 
     
        public static string handleNullValues(string value)
        {
            if (value == null)
            {
                return "Update Workday";
            }

            return value;
        }

        public static bool hasThumbnailPhoto(PropertyCollection properties, string property)
        {
            bool hasThumbnail = false;

            try
            {
                if (properties.Contains(property))
                {
                    hasThumbnail = true;
                }
            }
            catch (Exception ex)
            {
                string strErrMsg = ex.Message;
            }

            return hasThumbnail;
        }

        public static string IsNull(PropertyCollection properties, string property, string userName)
        {
            string value = "";

            try
            {
                if (properties.Contains(property))
                {
                    value = Convert.ToString(properties[property][0]);
                    if (value == null || value == "")
                    {
                        value = "NULL";
                    }
                }
                else
                {
                    return "Update Workday";
                }
            }
            catch (Exception ex)
            {
                string strErrMsg = ex.Message;
                //errorLogger.log("Error on IsNull check on " + property + " for " + userName);
            }

            return value;
        }

        public static string IsNull(string property)
        {
            string value = "";

            try
            {
                if (property != "")
                {
                    value = property;
                }
            }
            catch (Exception ex)
            {
                string strErrMsg = ex.Message;
            }

            return value;
        }
    }
}
