﻿using Microsoft.Extensions.Options;
using Photobook.Configurations.AppSetting;
using System.Collections.Specialized;

namespace Photobook.Utilities
{
    public abstract class iLogger
    {
        public abstract void log(string message);
        //public abstract void WriteEventLogEntry(System.Diagnostics.EventLogEntryType messageLevel, string message);
    }

    public class fileLogger : iLogger
    {
        private string logLevel;
        public static string logPath;
        private string fileName;

        private readonly ProtectedKeySection _protectedKeySection;

        public fileLogger(string logprefix, IOptions<ProtectedKeySection> protectedKeySectionSetting)
        {
            _protectedKeySection = protectedKeySectionSetting.Value;
            logPath = _protectedKeySection.root;
            logLevel = logprefix;
            // fileName = logPath + "log_" + DateTime.Today.ToString("MM-dd-yyyy") + ".txt";
            fileName = "C:\\inetpub\\wwwroot\\Photobook\\logs\\log.txt";
        }

        public override void log(string message)
        {
            if (System.IO.File.Exists(fileName))
            {
                using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(fileName, true))
                {
                    logFile.WriteLine(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "\t" +
                        "[" + logLevel + "]\t" + message);
                }
            }
            else
            {
                using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(fileName))
                {
                    logFile.WriteLine(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss") + "\t" +
                        "[" + logLevel + "]\t" + message);
                }
            }
        }

        //public override void WriteEventLogEntry(System.Diagnostics.EventLogEntryType messageLevel, string message)
        //{
        //    using (System.Diagnostics.EventLog eventLog = new System.Diagnostics.EventLog("Application"))
        //    {
        //        eventLog.Source = ".NET Runtime";
        //        eventLog.WriteEntry("Photobook: " + message, messageLevel, 1000);
        //    }
        //}

        public void delete()
        {
            if (System.IO.File.Exists(fileName))
            {
                System.IO.File.Delete(fileName);
            }
        }
    }
}
