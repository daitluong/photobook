﻿//using System;
//using System.Collections.Generic;
//using System.Collections.Specialized;
//using System.Configuration;
//using System.DirectoryServices;
//using System.DirectoryServices.AccountManagement;
//using System.Linq;
//using System.Web;
//using Photobook.Models;

//namespace Photobook.Utilities
//{
//    public class DAL
//    {
//        public DirectoryEntry directory;
//        public DirectoryEntry directoryNSC;
//        public DirectoryEntry directoryNSCGroups;
//        public DirectoryEntry directoryOVP;
//        public DirectorySearcher searcher;
//        public SearchResultCollection results;
//        public SearchResultCollection resultsNSC;
//        public SearchResultCollection resultsOVP;
//        public SearchResultCollection resultsNSCGroups;
//        public String message;
//        //public fileLogger infoLogger = new fileLogger("INFO");
//        //public fileLogger errorLogger = new fileLogger("ERROR");

//        public DAL() { }

//        public void ConnectToDirectory()
//        {
//            NameValueCollection protectedAD = (NameValueCollection)ConfigurationManager.GetSection("ProtectedKeysSection");
//            string username = protectedAD["ac"];
//            string password = protectedAD["ADAccountPwd"];
//            string ldapRoot = protectedAD["root"];
//            //string groupsRoot = protectedAD["groupsRoot"];

//            //infoLogger.log("Connect to directory: " + ldapRoot);

//            try
//            {
//                directoryNSC = new DirectoryEntry(ldapRoot, username, password);
//                directory = new DirectoryEntry(ldapRoot, username, password);
//                //directoryNSCGroups = new DirectoryEntry(groupsRoot, username, password);
//            }
//            catch (Exception ex)
//            {
//                //errorLogger.log("ConnectToDirectory() error: Error message; " + ex.Message + "; Stacktrace: " + ex.StackTrace);
//            }

//        }

//        public string GetUserProprties(Person person)
//        {
//            //infoLogger.log("Photoboook: Start GetUserProprties()");

//            NameValueCollection protectedAD = (NameValueCollection)ConfigurationManager.GetSection("ProtectedKeysSection");
//            string generalFilter = protectedAD["generalFilter"];

//            string accessType = "Reader";

//            try
//            {
//                searcher = new DirectorySearcher(directory)
//                {
//                    SearchScope = SearchScope.Subtree,
//                    Filter = "(&" + generalFilter +
//                    "(sAMAccountName=" + person.SAMAccountName + "*)" +
//                    ")"
//                };

//                searcher.PropertiesToLoad.Add("memberOf");
//                SearchResult result = searcher.FindOne();

//                if (result != null)
//                {
//                    int c = result.Properties["memberOf"].Count;
//                    string dn = "";

//                    //if(c != 0)
//                    //{
//                    //    for (int pc = 0; pc < c; pc++)
//                    //    {
//                    //        dn = (String)result.Properties["memberOf"][pc];
//                    //        foreach(string admin in ConfigurationManager.AppSettings["admins"].Split(';'))
//                    //        {
//                    //            if(dn.ToUpper().StartsWith(@"CN=\" + admin))
//                    //            {
//                    //                accessType = "Editor";
//                    //                foreach (string uploader in ConfigurationManager.AppSettings["uploaders"].Split(';'))
//                    //                {
//                    //                    if (dn.ToUpper().StartsWith(@"CN=\" + uploader))
//                    //                    {
//                    //                        accessType = "Administrator";
//                    //                        break;
//                    //                    }
//                    //                }
//                    //            }

//                    //            if(accessType == "Administrator")
//                    //            {
//                    //                break;
//                    //            }
//                    //        }
//                    //    }
//                    //}
//                }
//            }
//            catch (Exception ex)
//            {
//                //errorLogger.log("GetUserProperties exception: " + person.DisplayName + "; " + ex.Message + "; Stacktrace: " + ex.StackTrace);
//            }

//            //infoLogger.log("Photoboook: End GetUserProprties()");

//            return accessType;
//        } 
//    }
//}