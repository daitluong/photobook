﻿//using Microsoft.Extensions.Options;
//using Photobook.Configurations.AppSetting;
//using Photobook.Models;
//using System.DirectoryServices;
//using System.DirectoryServices.AccountManagement;

//namespace Photobook.Utilities
//{
//    public class ADServicesByPrincipal
//    {
//        private readonly PrincipalContext _principalContext;

//        public List<string> userNames = new List<string>();
//        public List<string> offices = new List<string>();
//        public List<Person> nscPeople = new List<Person>();

//        int numTotalMembers = 0;

//        private readonly ProtectedKeySection _protectedKeySection;
                 
//        public ADServicesByPrincipal(IOptions<ProtectedKeySection> options) {
//            _protectedKeySection = options.Value;
//            _principalContext = new PrincipalContext(ContextType.Domain, _protectedKeySection.pc);
//        }
 
//        public UserPrincipal FindUser(string samAccountName)
//        {
//            // Define a query-by-example principal
//            using (var userPrincipal = new UserPrincipal(_principalContext))
//            {
//                userPrincipal.SamAccountName = samAccountName;

//                // Create a searcher and find the user
//                using (var searcher = new PrincipalSearcher(userPrincipal))
//                {
//                    return searcher.FindOne() as UserPrincipal;
//                }
//            }
//        }

//        public bool IsUserInGroup(string samAccountName, string groupName)
//        {
//            UserPrincipal user = FindUser(samAccountName);
//            if (user != null)
//            {
//                // Check if the user is a member of the specified group
//                return user.IsMemberOf(_principalContext, IdentityType.SamAccountName, groupName);
//            }
//            return false;
//        }

//        public List<Person> GetNSCGroupMembers()
//        {
//            string contextDomain = _protectedKeySection.ac;
//            string ldapPath = _protectedKeySection.ldapPath; 

//            //infoLogger.log("Photobook: Start GetNSCGroupMembers()");  
//            DAL ad = new DAL(_protectedKeySection);
//            using (PrincipalContext context = new PrincipalContext(ContextType.Domain, contextDomain, ldapPath))
//            {
//                try
//                {
//                    GroupPrincipal grp = new GroupPrincipal(context);
//                    PrincipalSearcher srch = new PrincipalSearcher(grp);
//                    var groupsFound = srch.FindAll().Where(p => p.DisplayName == "#NSC-ALL");

//                    foreach (GroupPrincipal nscGrp in groupsFound)
//                    {
//                        string distName = nscGrp.DistinguishedName;

//                        ProcessPrincipals(nscGrp, context);
//                    }
//                }
//                catch (Exception ex)
//                {
//                    // errorLogger.log("GetNSCGroupMembers error: " + ex.Message + "; Stacktrace: " + ex.StackTrace);
//                }
//            }

//            //infoLogger.log("Photobook: End GetNSCGroupMembers()");

//            return nscPeople.OrderBy(name => name.DisplayName).ToList<Person>();
//        }

//        public void ProcessPrincipals(GroupPrincipal grp, PrincipalContext context)
//        {
//            //infoLogger.log("Start ProcessPrincipals() for group " + grp.DisplayName);

//            string grpName = grp.DisplayName;

//            if (!grpName.Contains("NSC-ALL") && !grpName.Contains("OVP-ALL"))
//            {
//                if (!offices.Contains(grpName.Trim().Replace("#NSC-", "").ToUpper()))
//                {
//                    offices.Add(grpName.Trim().Replace("#NSC-", "").ToUpper());
//                }
//            }

//            offices.Sort();

//            foreach (Principal p in grp.Members)
//            {
//                try
//                {
//                    Type type = p.GetType();

//                    if (type == typeof(UserPrincipal) && p.StructuralObjectClass != "Group")
//                    {
//                        UserPrincipal user = new UserPrincipal(context);
//                        user = (UserPrincipal)p;

//                        if (user.GivenName != null
//                            && !user.DisplayName.Contains("WHCA")
//                            && !user.DisplayName.Contains("OVP")
//                            && !user.DisplayName.Contains("OA")
//                            && !user.DisplayName.Contains("WHMO"))
//                        {
//                            string userGivenName = "";
//                            string userSurname = "";
//                            string userDepartment = "";
//                            string userTitle = "";
//                            string userInitials = "";
//                            string userPhone = "";
//                            string userOtherPhone = "";
//                            string userMobile = "";
//                            string userPhysicalDeliveryOfficeName = "";
//                            string userCompany = "";
//                            string userDeskNumber = "";

//                            DirectoryEntry de = user.GetUnderlyingObject() as DirectoryEntry;

//                            //foreach (string strProperty in de.Properties.PropertyNames)
//                            //{
//                            //    infoLogger.log(strProperty + ": " + de.Properties[strProperty].Value);
//                            //}

//                            if (de != null)
//                            {
//                                userGivenName = IsNull(de.Properties, "givenname", userGivenName);
//                                userSurname = IsNull(de.Properties, "sn", userGivenName);
//                                userDepartment = IsNull(de.Properties, "department", userGivenName);
//                                userTitle = IsNull(de.Properties, "title", userGivenName);
//                                userPhone = IsNull(de.Properties, "telephoneNumber", userGivenName);
//                                userOtherPhone = IsNull(de.Properties, "otherTelephone", userGivenName);
//                                userMobile = IsNull(de.Properties, "mobile", userGivenName);
//                                userPhysicalDeliveryOfficeName = IsNull(de.Properties, "physicaldeliveryofficename", userGivenName);
//                                userCompany = IsNull(de.Properties, "company", userGivenName);
//                                userDeskNumber = IsNull(de.Properties, "business 2", userGivenName);

//                                Person nscPerson = new Person
//                                {
//                                    SAMAccountName = IsNull(p.SamAccountName),
//                                    GivenName = IsNull(userGivenName),
//                                    Initials = IsNull(userInitials),
//                                    SN = IsNull(userSurname),
//                                    DisplayName = IsNull(p.DisplayName),
//                                    Title = IsNull(userTitle),
//                                    Company = IsNull(userCompany),
//                                    Department = IsNull(userDepartment),
//                                    PhysicalDeliveryOfficeName = IsNull(userPhysicalDeliveryOfficeName),
//                                    TelephoneNumber = IsNull(userDeskNumber),
//                                    OtherTelephoneNumber = IsNull(userOtherPhone),
//                                    MobileTelephoneNumber = IsNull(userMobile)

//                                };

//                                byte[] data = null;

//                                try
//                                {

//                                    if (hasThumbnailPhoto(de.Properties, "thumbnailPhoto"))
//                                    {
//                                        data = (byte[])de.Properties["thumbnailPhoto"][0];
//                                        nscPerson.Image = String.Format("data:image/jpeg;base64,{0}", Convert.ToBase64String(data));
//                                    }
//                                    else
//                                    {
//                                        nscPerson.Image = "/images/NoPhoto.jpg";
//                                    }
//                                }
//                                catch (Exception ex)
//                                {
//                                    //errorLogger.log("Get user thumbnail error for " + p.DisplayName + "; Error message: " + ex.Message + "; Stacktrace: " + ex.StackTrace);
//                                }

//                                if (!userNames.Contains(user.DisplayName)
//                                    && !userDepartment.Contains("WHCA")
//                                    && !user.DisplayName.Contains("WHMO")
//                                    && !userDepartment.Contains("OPPR")
//                                    && !userDepartment.Contains("NCD")
//                                    && !userDepartment.Contains("OSTP")
//                                    && !userDepartment.Contains("OA")
//                                    && !userDepartment.Contains("OVP"))
//                                {
//                                    numTotalMembers++;
//                                    userNames.Add(user.DisplayName);
//                                    //infoLogger.log("SAMAccountName: " + user.SamAccountName);
//                                    nscPeople.Add(nscPerson);
//                                }
//                            }
//                        }

//                        //infoLogger.log(p.DisplayName + " processed");
//                    }
//                    else
//                    {
//                        GroupPrincipal subGroup = new GroupPrincipal(context);
//                        subGroup = (GroupPrincipal)p;
//                        //infoLogger.log("Subgroup: " + subGroup.DisplayName);

//                        ProcessPrincipals(subGroup, context);
//                    }
//                }
//                catch (Exception ex)
//                {
//                    // errorLogger.log("Error processing " + p.DisplayName + " in group " + grp.DisplayName + "; Error message: " + ex.Message + "; Stacktrace: " + ex.StackTrace);
//                }
//            }
//        }

//        public bool hasThumbnailPhoto(PropertyCollection properties, string property)
//        {
//            bool hasThumbnail = false;

//            try
//            {
//                if (properties.Contains(property))
//                {
//                    hasThumbnail = true;
//                }
//            }
//            catch (Exception ex)
//            {
//                string strErrMsg = ex.Message;
//            }

//            return hasThumbnail;
//        }

//        public string IsNull(PropertyCollection properties, string property, string userName)
//        {
//            string value = "";

//            try
//            {
//                if (properties.Contains(property))
//                {
//                    value = Convert.ToString(properties[property][0]);
//                }
//            }
//            catch (Exception ex)
//            {
//                string strErrMsg = ex.Message;
//                //errorLogger.log("Error on IsNull check on " + property + " for " + userName);
//            }

//            return value;
//        }

//        public string IsNull(string property)
//        {
//            string value = "";

//            try
//            {
//                if (property != "")
//                {
//                    value = property;
//                }
//            }
//            catch (Exception ex)
//            {
//                string strErrMsg = ex.Message;
//            }

//            return value;
//        }

//    }
//}

