using Photobook.Services; 
using Photobook.Configurations.AppSetting;
using log4net;
using log4net.Config;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Photobook.Models;

[ApiController]
[Route("api/[controller]")]
public class ActiveDirectoryController : ControllerBase
{
    private readonly IActiveDirectorySercies _activeDirectoryService;      
 
    public ActiveDirectoryController(IActiveDirectorySercies activeDirectoryService)
    {
        _activeDirectoryService = activeDirectoryService;
    }   
 
    [HttpGet("GetADAccounts")]
    public IActionResult GetADAccounts(string department=null, string fullname=null)
    {
        List<Person> people = _activeDirectoryService.SearchByFullName(department, fullname);
                
        return Ok(people);
    }

    [HttpPost("AddPerson")]
    public IActionResult AddPerson(Person model)
    {
         
        if (model == null)
            return BadRequest(); 
                
        return Ok();
    }
}