#!/usr/bin/env bash
set -euo pipefail

# start-all.sh
# Starts the LDAP docker stack and then the Photobook application.
# Usage: ./start-all.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_FILE="$SCRIPT_DIR/docker-compose.ldap.yml"
PHOTBOOK_DIR="$SCRIPT_DIR/backend"
LDAP_CONTAINER_NAME="photobook-ldap"
LDAP_ADMIN_DN='cn=admin,dc=photobook,dc=local'
LDAP_ADMIN_PW='admin123'
LDAP_URL='ldap://localhost'
LDAP_PORT=389
LDAP_BASE_DN='dc=photobook,dc=local'

echo "[start-all] Starting LDAP stack using $COMPOSE_FILE..."
docker compose -f "$COMPOSE_FILE" up -d

# Wait for LDAP to be ready
echo "[start-all] Waiting for LDAP (${LDAP_CONTAINER_NAME}) to respond (timeout 60s)..."
READY=0
for i in {1..60}; do
  if docker exec "$LDAP_CONTAINER_NAME" ldapwhoami -x -H "${LDAP_URL}:${LDAP_PORT}" -D "$LDAP_ADMIN_DN" -w "$LDAP_ADMIN_PW" >/dev/null 2>&1; then
    READY=1
    echo "[start-all] LDAP is ready (after ${i}s)."
    break
  fi
  sleep 1
done

if [ "$READY" -ne 1 ]; then
  echo "[start-all] ERROR: LDAP did not become ready within 60 seconds. Check container logs:" >&2
  echo "  docker compose -f $COMPOSE_FILE logs $LDAP_CONTAINER_NAME" >&2
  exit 1
fi

# Populate LDAP with test users if none exist
echo "[start-all] Checking for existing users in LDAP..."
USER_COUNT=$(docker exec "$LDAP_CONTAINER_NAME" ldapsearch -x -H "${LDAP_URL}:${LDAP_PORT}" -D "$LDAP_ADMIN_DN" -w "$LDAP_ADMIN_PW" -b "ou=users,${LDAP_BASE_DN}" "(uid=user*)" 2>/dev/null | grep "^dn:" | wc -l || true)
if [ "${USER_COUNT}" -gt 0 ]; then
  echo "[start-all] LDAP already contains ${USER_COUNT} user(s); skipping import."
else
  echo "[start-all] No users found in LDAP; attempting to import LDIF..."
  # Prefer the comprehensive 200-user LDIF if present
  if [ -f "$SCRIPT_DIR/add-200-users.ldif" ]; then
    LDIF_SRC="$SCRIPT_DIR/add-200-users.ldif"
  elif [ -f "$SCRIPT_DIR/ldap-init-users.ldif" ]; then
    LDIF_SRC="$SCRIPT_DIR/ldap-init-users.ldif"
  elif [ -f "$SCRIPT_DIR/add-users.ldif" ]; then
    LDIF_SRC="$SCRIPT_DIR/add-users.ldif"
  else
    echo "[start-all] WARNING: No LDIF file found to import. Skipping user import." >&2
    LDIF_SRC=""
  fi

  if [ -n "$LDIF_SRC" ]; then
    echo "[start-all] Copying $LDIF_SRC into container $LDAP_CONTAINER_NAME:/tmp/users.ldif"
    docker cp "$LDIF_SRC" "$LDAP_CONTAINER_NAME":/tmp/users.ldif

    echo "[start-all] Running ldapadd to import users..."
    if docker exec "$LDAP_CONTAINER_NAME" ldapadd -x -H "${LDAP_URL}:${LDAP_PORT}" -D "$LDAP_ADMIN_DN" -w "$LDAP_ADMIN_PW" -f /tmp/users.ldif >/dev/null 2>&1; then
      echo "[start-all] LDIF import completed successfully."
    else
      echo "[start-all] ERROR: LDIF import failed. See container logs for details:" >&2
      echo "  docker compose -f $COMPOSE_FILE logs $LDAP_CONTAINER_NAME" >&2
    fi
  fi
fi

echo "Make sure ldap-utils is installed locally for ldapsearch command by update and install if needed..."
sudo apt-get update
sudo apt-get install -y ldap-utils

# Start Photobook app
echo "[start-all] Starting Photobook application from $PHOTBOOK_DIR ..."
cd "$PHOTBOOK_DIR"

# create logs dir if missing
mkdir -p "$PHOTBOOK_DIR/bin/Debug/net8.0/logs"

# Start the app in background and capture PID
DOTNET_OUT_LOG="$PHOTBOOK_DIR/photobook.stdout.log"
DOTNET_ERR_LOG="$PHOTBOOK_DIR/photobook.stderr.log"

echo "[start-all] Running: dotnet run (output -> $DOTNET_OUT_LOG)"
nohup dotnet watch run >"$DOTNET_OUT_LOG" 2>"$DOTNET_ERR_LOG" &
APP_PID=$!
echo "$APP_PID" > "$PHOTBOOK_DIR/photobook.pid"

sleep 2
if ps -p "$APP_PID" >/dev/null 2>&1; then
  echo "[start-all] Photobook started (PID: $APP_PID)."
  echo "[start-all] Tail last 40 lines of app log file(s):"
  echo
  tail -n 40 "$DOTNET_OUT_LOG" || true
else
  echo "[start-all] ERROR: Photobook failed to start. Check logs:" >&2
  echo "  $DOTNET_OUT_LOG" >&2
  echo "  $DOTNET_ERR_LOG" >&2
  exit 1
fi

echo
echo "[start-all] Done. To stop:"
echo "  kill \\$(cat $PHOTBOOK_DIR/photobook.pid) ; docker compose -f $COMPOSE_FILE down"

exit 0
