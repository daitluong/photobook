import { Component } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';


@Component({
  selector: 'app-nscnav',
  imports: [MatMenuModule, MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule],
  templateUrl: './nscnav.html',
  styleUrl: './nscnav.css',
})
export class Nscnav {

}
