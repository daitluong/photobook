import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nscnav } from './nscnav';

describe('Nscnav', () => {
  let component: Nscnav;
  let fixture: ComponentFixture<Nscnav>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Nscnav]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Nscnav);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
