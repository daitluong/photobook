import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Personprofile } from './personprofile';

describe('Personprofile', () => {
  let component: Personprofile;
  let fixture: ComponentFixture<Personprofile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Personprofile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Personprofile);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
