import { ChangeDetectionStrategy, Component, input, inject } from '@angular/core';
import { Person } from '../person'
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import {
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogTitle,
} from '@angular/material/dialog';
import { PersonProfileDialog } from "../person-profile-dialog/person-profile-dialog";
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-personprofile',
  templateUrl: './personprofile.html',
  styleUrl: './personprofile.css',
  imports: [RouterLink, MatCardModule, MatButtonModule, MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, PersonProfileDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Personprofile {
  PersonProfile = input.required<Person>();
   
  constructor(private dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(PersonProfileDialog, {       
      width: '800px',         
      maxWidth: 'none', 
      height: 'auto',
      maxHeight: 'none',
      data: {
        person: this.PersonProfile,
      },
    });
  }
}
