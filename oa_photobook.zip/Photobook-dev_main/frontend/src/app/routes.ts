import {Routes} from '@angular/router';
import {Home} from './home/home';
import {PersonProfileDialog} from './person-profile-dialog/person-profile-dialog';


const routeConfig: Routes = [
  {
    path: '',
    component: Home,
    title: 'Home page',
  },
  {
    path: 'person-profile-dialog/:id',
    component: PersonProfileDialog,
    title: 'Home details',
  },
];
export default routeConfig;