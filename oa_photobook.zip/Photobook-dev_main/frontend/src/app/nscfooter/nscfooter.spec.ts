import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Nscfooter } from './nscfooter';

describe('Nscfooter', () => {
  let component: Nscfooter;
  let fixture: ComponentFixture<Nscfooter>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Nscfooter]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Nscfooter);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
