import { Component } from '@angular/core';

@Component({
  selector: 'app-nscfooter',
  imports: [],
  templateUrl: './nscfooter.html',
  styleUrl: './nscfooter.css',
})
export class Nscfooter {

}
