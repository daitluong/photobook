import { Component, inject, OnInit, VERSION, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Personprofile } from '../personprofile/personprofile' //frontend componen
import { Person } from '../person';
import { MatGridListModule } from '@angular/material/grid-list';
import { PeopleService } from '../people.service';

@Component({
  selector: 'app-home',
  imports: [Personprofile, MatGridListModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})

export class Home {
  private readonly changeDectorRef = inject(ChangeDetectorRef);
  people: Person[] = [];
  peopleService: PeopleService = inject(PeopleService);
  filteredPeople: Person[] = [];

  constructor() {
    this.peopleService.getPeople().then((people: Person[]) => { this.people = people; this.filteredPeople = people; this.changeDectorRef.markForCheck(); });
  }

  filterResults(text: string) {
    if (!text) {
      this.filteredPeople = this.people;
      return;
    }

    this.filteredPeople = this.people.filter((person) =>
      person?.DisplayName.toLowerCase().includes(text.toLowerCase()),
    );
  }
}


