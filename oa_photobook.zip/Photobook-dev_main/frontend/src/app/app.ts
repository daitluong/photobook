import {Component, signal } from '@angular/core';
import {Nscnav} from './nscnav/nscnav'; 
import {Home} from './home/home' 
import {Nscfooter} from './nscfooter/nscfooter' 
import { RouterLink, RouterOutlet } from '@angular/router';

 
@Component({
  selector: 'app-root',
  imports: [Nscnav, Home, Nscfooter, RouterLink, RouterOutlet], 
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Photobook Client running on Angular 16');
}
