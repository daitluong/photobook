import { Injectable } from '@angular/core';
import { Person } from './person';
@Injectable({
  providedIn: 'root',
})
export class PeopleService {
  url = 'https://expert-halibut-qv9jg7wq47qcxxqj-5134.app.github.dev/api/ActiveDirectory/GetADAccounts';

  async getPeople(): Promise<Person[]> {  

    const data = await fetch(this.url);  

    return (await data.json()) ?? {};
  } 

  async getPeopleBySAMAccount(SAMAccountName: string): Promise<Person | undefined> {
    const data = await fetch(`${this.url}?SAMAccountName=${SAMAccountName}`);
    const people = await data.json();
    return people[0] ?? {};
  }

  async getPeopleByDepartment(department: string): Promise<Person[]> {
    const data = await fetch(`${this.url}?department=${department}`);
    return await data.json();
  }

  async getPeopleByLocation(location: string): Promise<Person | undefined> {
    const data = await fetch(`${this.url}?location=${location}`); 
    const locationJson = await data.json();
    return locationJson[0] ?? {};
  }

  submitApplication(firstName: string, lastName: string, email: string) {
     
    console.log(firstName, lastName, email);
  } 
}
