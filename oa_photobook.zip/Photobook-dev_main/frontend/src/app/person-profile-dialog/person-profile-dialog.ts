import {ChangeDetectorRef, Component, inject, input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { Person } from '../person'
import {
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogTitle,
} from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { PeopleService } from '../people.service';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';


@Component({
  selector: 'app-person-profile-dialog',
  imports: [MatCardModule, MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, MatGridListModule, ReactiveFormsModule],
  templateUrl: './person-profile-dialog.html',
  styleUrl: './person-profile-dialog.css',
})
export class PersonProfileDialog { 
  route: ActivatedRoute = inject(ActivatedRoute);
  peopleService = inject(PeopleService);
  personInfo: Person | undefined;

  constructor() {
    const SAMAccountName = this.route.snapshot.params['SAMAccountName'];
    this.peopleService.getPeopleBySAMAccount(SAMAccountName).then((personInfo) => { this.personInfo = personInfo;});
  }
}
