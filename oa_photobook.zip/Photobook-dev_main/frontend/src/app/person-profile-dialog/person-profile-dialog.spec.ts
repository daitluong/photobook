import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonProfileDialog } from './person-profile-dialog';

describe('PersonProfileDialog', () => {
  let component: PersonProfileDialog;
  let fixture: ComponentFixture<PersonProfileDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PersonProfileDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PersonProfileDialog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
