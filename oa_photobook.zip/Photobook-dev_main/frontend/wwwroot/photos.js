$(document).ready(function () {

    $("#loading").hide();
    $("#searchControls").show();
    $("#telephoneExample").hide();
    $("#locationExample").hide();

    var col1 = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < col1.length; i++) {
        col1[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
                content.style.display = "none";
            } else {
                content.style.display = "block";
            }
        });
    };

    $(function () {
        $("#sortable").sortable({
            forcePlaceholderSize: true,
            tolerance: 'pointer',
            cursor: 'pointer',
        })
        $("#sortable").disableSelection();
    });

    $(document).on('click', 'div.removeItem', function () {
        $(this).closest('li').remove();
    });

    $(document).on('click', 'div.removeItem', function () {
        $(this).closest('div.sut-contact-card').remove();
        //    $(this).closest('div.card').remove();
    });

    //<%--$("#<%=btnClear.ClientID %>").click(function () {
    //    $("#searchControls").hide();
    //$("#loading").show();
    //        });--%>

    /*$("#<%=btnSearch.ClientID %>").click(function () {
        //var search = $("#<%=txtSearchBox.ClientID %>").val();
        //var office = $("#<%=ddlOffices.ClientID %>").val()

        if (search === "" && office === "") {
            //$("#searchControls").hide();
            //$("#loading").show();
        }
    });*/

    /*$("#<%=ddlOffices.ClientID %>").change(function () {
        if ($(this).val === "") {
            //$("#searchControls").hide();
            //$("#loading").show();
        }
    });*/

    $("#personModal").keyup(function (e) {
        if (e.keyCode == 13 || e.which == 13) {
            $("#btnSave").click();
        }
    });

    $("div").on("click", ".contactCard", function () {
        //        debugger;
        var ag = $("#accessType").val();
        // if (ag === "Administrator") {
        //  $("#fileuploaderSection").show();

        var person = {};
        var personImageValue = $(this).find(".photo").attr('src');
        person["Image"] = personImageValue;
        person["displayName"] = $(this).find(".displayName").text();
        person["title"] = $(this).find(".title").text();
        person["physicalDeliveryOfficeName"] = $(this).find(".physicalDeliveryOfficeName").text();
        person["Department"] = $(this).find(".department").text();
        person["phone3"] = $(this).find(".phone3").children().first().html();
        person["sAMAccountName"] = $(this).find(".sAMAccountName").text();

        $("#modalPhoto").attr('src', person["Image"]);
        $("#displayName").text(person["displayName"]);
        $("#txtTitle").text(person["title"]);
        $("#lblDepartment").text(person["Department"]);
        $("#account").val(person["sAMAccountName"]);
        $("#txtLocation").text(person["physicalDeliveryOfficeName"]);
        $("#txtTelephoneNumber3").html(person["phone3"]);
        $("#personModal").modal('show');

        // }
    });

    $("#btnClose").click(function () {
        $("#displayName").text("");
        $("#txtTitle").val("");
        $("#txtLocation").val("");
        $("#lblDepartment").text("");
        $("#account").val("");
        $("#txtTelephoneNumber3").val("");
        $("#FileUpload1").val("");
        $("#personModal").modal('hide');
    });

    $("#txtTelephoneNumber").mouseenter(function () {
        $("#telephoneExample").show();
    });

    $("#txtTelephoneNumber").mouseleave(function () {
        $("#telephoneExample").show();
    });

    $("#txtLocation").mouseenter(function () {
        $("#locationExample").hide();
    });

    $("#txtLocation").mouseleave(function () {
        $("#locationExample").hide();
    });

    //$("#txtTelephoneNumber").keyup(function () {
    //    var reg = /^\d{3}-\d{4}$/;
    //    var str = $(this).val();
    //    var valid = reg.test(str);

    //    //alert(valid);
    //});

    //Refresh the page when clicked on the "PhotoBook" text
    //$("#refresh-page").click(function () {
    //    $("#txtSearchBox").val("");
    //    $("#ddlOffices").val("0");
    //    $("#ddlDistroGroup").val("0");

    //    //alert("all clear");
    //    document.location.reload(true);
    //    //    alert("reload");
    //});

    //});

    function CloseModal() {
        $("#personModal").modal('hide');
    };

});
