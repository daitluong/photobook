#!/usr/bin/env node

const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = 4200;

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname)));

// Proxy API calls to backend
app.use('/api', createProxyMiddleware({
  target: 'http://api:5000',
  changeOrigin: true,
  pathRewrite: {
    '^/api': '/api'
  },
  onError: (err, req, res) => {
    console.error('Proxy error:', err);
    res.status(500).json({ error: 'Proxy error', message: err.message });
  },
  onProxyReq: (proxyReq, req, res) => {
    console.log(`[PROXY] ${req.method} ${req.path} -> http://api:5000${req.path}`);
  }
}));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`✓ Frontend server running on http://0.0.0.0:${PORT}`);
  console.log(`✓ API requests proxied to http://api:5000`);
});
