#!/usr/bin/env python3
import random
import string

# Generate LDIF header
ldif_content = """dn: dc=photobook,dc=local
objectClass: top
objectClass: dcObject
objectClass: organization
o: Photobook
dc: photobook

dn: ou=users,dc=photobook,dc=local
objectClass: top
objectClass: organizationalUnit
ou: users

"""

# Generate 200 random users
first_names = ["John", "Jane", "Michael", "Emily", "David", "Sarah", "Robert", "Lisa", "James", "Mary",
               "William", "Patricia", "Richard", "Jennifer", "Joseph", "Linda", "Thomas", "Barbara", "Charles", "Susan",
               "Christopher", "Jessica", "Daniel", "Sarah", "Matthew", "Karen", "Mark", "Nancy", "Donald", "Lisa",
               "Steven", "Betty", "Paul", "Margaret", "Andrew", "Sandra", "Joshua", "Ashley", "Kenneth", "Kimberly",
               "Kevin", "Donna", "Brian", "Carol", "Edward", "Michelle", "Ronald", "Emily", "Anthony", "Melissa"]

last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
              "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
              "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
              "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Peterson", "Phillips", "Campbell",
              "Parker", "Evans", "Edwards", "Collins", "Reeves", "Stewart", "Morris", "Morales", "Murphy", "Cook"]

random.seed(42)  # For reproducible results
for i in range(1, 201):
    first_name = random.choice(first_names)
    last_name = random.choice(last_names)
    username = f"user{i:03d}"
    email = f"{username}@photobook.local"
    password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
    
    uid = f"uid={username},ou=users,dc=photobook,dc=local"
    
    ldif_content += f"""dn: {uid}
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: {first_name} {last_name}
sn: {last_name}
givenName: {first_name}
uid: {username}
userPassword: {password}
mail: {email}
displayName: {first_name} {last_name}
description: Test user {i}

"""

# Write LDIF file
with open('/workspaces/Photobook/ldap-init.ldif', 'w') as f:
    f.write(ldif_content)

print(f"Generated LDIF file with 200 test users")
print(f"File location: /workspaces/Photobook/ldap-init.ldif")
print(f"\nSample credentials:")
print(f"  Username: user001")
print(f"  Password: Check the generated file")
print(f"\nLDAP Admin:")
print(f"  DN: cn=admin,dc=photobook,dc=local")
print(f"  Password: admin123")
