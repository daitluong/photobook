# Photobook

This repository contains the Photobook application and supporting dev tooling (LDAP test server configuration).

## Development: start LDAP + Photobook

A helper script is provided to start the LDAP Docker stack (OpenLDAP + phpLDAPadmin) and then start the Photobook application.

Run from the repository root:

```bash
cd /workspaces/Photobook
./start-all.sh
```

What the script does:
- Brings up the LDAP containers defined in `docker-compose.ldap.yml`.
- Waits for the LDAP server to become responsive (uses `ldapwhoami` inside the container).
- Starts the Photobook application with `dotnet run` in the background and writes stdout/stderr to `Photobook/photobook.stdout.log` and `Photobook/photobook.stderr.log`.

Stopping the services started by the script:

```bash
# stop the Photobook process (if started by the script)
kill $(cat /workspaces/Photobook/Photobook/photobook.pid) || true

# take down the LDAP containers and network


```

Logs & troubleshooting:
- Tail Photobook stdout/stderr:

```bash
tail -f /workspaces/Photobook/Photobook/photobook.stdout.log /workspaces/Photobook/Photobook/photobook.stderr.log
```

- See OpenLDAP logs:

```bash
docker compose -f docker-compose.ldap.yml logs -f openldap
```

- If Docker Compose fails, try the legacy command:

```bash
docker-compose -f docker-compose.ldap.yml up -d
```

## LDAP credentials (dev)
- Admin DN: `cn=admin,dc=photobook,dc=local`
- Admin password: `admin123`
- Base DN: `dc=photobook,dc=local`
- phpLDAPadmin UI: http://localhost:8080 (login with admin DN and password)

## Notes
- The `start-all.sh` script is opinionated for the development environment in this repository; review it before use if you adapt to other environments.
- The Photobook application is run with `dotnet watch run` during development for hot reload. The project will compile anytime we update the source code. 
